import subprocess

# Jalankan file shell script
result = subprocess.run(["./index.sh"], capture_output=True, text=True)

# Tampilkan output dari shell script
print(result.stdout)

# Tampilkan error jika ada
if result.stderr:
    print("Error:", result.stderr)
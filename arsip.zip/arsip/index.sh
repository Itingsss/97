dev=@Brokoll11
ver=1.0
ex=Brokoll11
id=fa36dd0e-8132-4a25-80e8-e63de2258780
TOUCH_RESPONSIVENESS="on"
X_SENSITIVITY=1.5
Y=SENSITIVITY=1.5
CACHE_DIR0=/storage/emulated/0/Android/data/com.dts.freefireth/files/ffrtc_log.txt
CACHE_DIR1=/storage/emulated/0/Android/data/com.dts.freefireth/files/ffrtc_log_bak.txt
CACHE_DIR2=/storage/emulated/0/Android/data/com.dts.freefiremax/files/ffrtc_log.txt
CACHE_DIR3=/storage/emulated/0/Android/data/com.dts.freefiremax/files/ffrtc_log_bak.txt
eval_1=https://linktr.ee/GsByBr0k0l1
prop() {
setprop $2 $1
}
etc() {
settings put global $2 $1
}
game() {
settings put secure $2 $1
}
fuleset() {
settings put system $2 $1
}
net() {
settings put --user 0 global $1 $2
}
sensix() {
wm size $1
}
#memeriksa apakah ID diblokir
source sh /sdcard/GS/blocker.sh

# Jika ID tidak diblokir, script ini akan dilanjutkan
echo "Menjalankan script_yang_diblokir.sh..."
printf "
╔═══╗╔╗────╔═══╗──╔╗─╔╗
║╔══╝║║────║╔═╗║─╔╝╚╦╝╚╗
║╚══╦╣║╔══╗║╚══╦═╩╗╔╩╗╔╬╦═╗╔══╗
║╔══╬╣║║║═╣╚══╗║║═╣║─║║╠╣╔╗╣╔╗║
║║──║║╚╣║═╣║╚═╝║║═╣╚╗║╚╣║║║║╚╝║
╚╝──╚╩═╩══╝╚═══╩══╩═╝╚═╩╩╝╚╩═╗║
───────────────────────────╔═╝║
───────────────────────────╚══╝"
echo ""
echo ""
sleep 1
echo "[ 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 𝗔𝗯𝗼𝘂𝘁 ] "
echo "Developer : ${dev} "
echo "Version : ${ver} "
echo "User : ${id}"
echo ""
sleep 0.3
echo ""
sleep 3
echo "[ FileSetting ]"
sleep 1.2
echo "[◘] Installed..."
sensix 1080x2400
sleep 5
{
settings put system peak_refresh_rate 90
settings put system user_refresh_rate 90
settings put system thermal_limit_refresh_rate 90
} > /dev/null 2>&1
sleep 5
lib_ocos() {
function lib32 {
    settings put secure $1 $2
}
lib32 multi_press_timeout "$1"> /dev/null 2>&1
lib32 long_press_timeout "$2"> /dev/null 2>&1
}
game_opt() {
settings put global game_mode 1
settings put global debug_hwui 1
settings put global animator_duration_scale 0
settings put global transition_animation_scale 0
settings put global window_animation_scale 0
settings put system min_refresh_rate_for_fps_boost 90
settings put system max_refresh_rate_for_fps_boost 90
settings put system tran_need_recovery_refresh_mode 90
settings put system last_tran_refresh_mode_in_refresh_setting 90
settings put system tran_refresh_mode 90
settings put system peak_refresh_rate 90.0 
settings put system min_refresh_rate 90.0 
settings put system user_refresh_rate 90.0 
settings put system max_refresh_rate 90.0 
settings put secure miui_refresh_rate 90.0 
settings put secure user_refresh_rate 90.0 
settings put global fstrim_mandatory_interval 1 
settings delete system thermal_limit_refresh_rate 
settings put system rt_templimit_ceiling 100 
settings put secure game_auto_temperature_control 0 
settings put secure thermal_temp_state_vaule 0 
settings put global tran_temp_battery_warning 0 
settings put global game_temperature_control 0 
settings put system touchscreen_response $TOUCH_RESPONSIVENESS
echo $X_SENSITIVITY > /sys/class/touchscreen/touchpad/sensitivity_x
echo $Y_SENSITIVITY > /sys/class/touchscreen/touchpad/sensitivity_y
} > /dev/null 2>&1
sleep 5
dumpsys deviceidle whitelist +com.dts.freefireth> /dev/null 2>&1
dumpsys deviceidle whitelist +com.dts.freefiremax> /dev/null 2>&1
prop false debug.egl.force_msaa> /dev/null 2>&1
prop false debug.egl.force_fxaa> /dev/null 2>&1
prop false debug.egl.force_taa> /dev/null 2>&1
prop false debug.egl.force_smaa> /dev/null 2>&1
prop 3000 debug.slow_query_threshold> /dev/null 2>&1
prop true debug.hwui.skip_empty_damage> /dev/null 2>&1
prop 45 debug.hwui.target_cpu_time_percent> /dev/null 2>&1
prop true debug.hwui.capture_skp_enabled> /dev/null 2>&1
prop 2 debug.hwui.capture_skp_frames> /dev/null 2>&1
sleep 5
external_exe() {
x1=$(expr $RANDOM % 1000 + 1)
y1=$(expr $RANDOM % 1000 + 1)
x2=$(expr $RANDOM % 1000 + 1)
y2=$(expr $RANDOM % 1000 + 1)
duration=$(expr $RANDOM % 1000 + 500)
swipe_command="input swipe $x1 $y1 $x2 $y2 $duration -1"
$swipe_command
}
aim_tracking_opt() {
  local coordinate=$1
  if [ $coordinate -lt 0 ]; then
    coordinate=0
  elif [ $coordinate -gt 1000 ]; then 
    coordinate=1000
  fi
  echo $coordinate
}
sensi_calibrar() {
  local x=$(expr $RANDOM % 1000 + 1)
  local y=$(expr $RANDOM % 1000 + 1)
  local duration=$(expr $RANDOM % 1000 + 500)

  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 2000 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 0 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 2000 $duration 
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 0 $duration

  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 2000 2000 $duration
  external_exe swipe $(aim_tracking_opt $x) $(aim_tracking_opt $y) 0 2000 $duration
}
external_exe
sensi_calibrar
sleep 5
prop skiagl debug.hwui.renderer> /dev/null 2>&1
prop 1200000 debug.sf.early.app.duration
prop 1200000 debug.sf.early.sf.duration
prop 1200000 debug.sf.earlyGl.app.duration
prop 1200000 debug.sf.earlyGl.sf.duration
prop 1200000 debug.sf.early_app_phase_offset_ns
prop 1200000 debug.sf.early_gl_app_phase_offset_ns
prop 1200000 debug.sf.early_phase_offset_ns
prop 1200000 debug.sf.high_fps.early.app.duration
prop 1200000 debug.sf.high_fps.early.sf.duration 
prop 1200000 debug.sf.high_fps.earlyGl.app.duration 
prop 1200000 debug.sf.high_fps.hwc.min.duration 
prop 1800000 debug.sf.high_fps.late.app.duration 
prop 1800000 debug.sf.high_fps.late.sf.duration 
prop 1200000 debug.sf.high_fps_early_app_phase_offset_ns 
prop 1200000 debug.sf.high_fps_early_cpu_app_offset_ns
prop 1200000 debug.sf.high_fps_early_gl_app_phase_offset_ns
prop 1200000 debug.sf.high_fps_early_gpu_app_offset_ns 
prop 1200000 debug.sf.high_fps_early_phase_offset_ns 
prop 1800000 debug.sf.high_fps_late_app_phase_offset_ns 
prop 1800000 debug.sf.high_fps_late_gl_phase_offset_ns
prop 1800000 debug.sf.high_fps_late_phase_offset_ns
prop 1800000 debug.sf.high_fps_late_sf_phase_offset_ns
prop 1200000 debug.sf.perf_fps_early_gl_phase_offset_ns
rm -r /sdcard/Android/data/com.dts.freefireth/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefiremax/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefireth/cache/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefireth/files/il2cpp/*> /dev/null 2>&1
rm -r /sdcard/Android/data/com.dts.freefiremax/files/il2cpp/*> /dev/null 2>&1
rm -f /data/local/traces/*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefireth/files/ffrtc_log.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefireth/files/ffrtc_log_bak.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefiremax/files/ffrtc_log.txt*> /dev/null 2>&1
rm -f /sdcard/Android/data/com.dts.freefiremax/files/ffrtc_log_bak.txt*> /dev/null 2>&1
sleep 5
settings delete system thermal_limit_refresh_rate> /dev/null 2>&1
etc 1 com.android.settings.superscript_count> /dev/null 2>&1
etc 1 enable_gpu_debug_layers> /dev/null 2>&1
sleep 5
etc 1 zen_mode> /dev/null 2>&1
etc ENABLE sem_enhanced_cpu_responsiveness> /dev/null 2>&1
sensix 1 screen_game_mode> /dev/null 2>&1
sensix 1 perf_game_oom_enable> /dev/null 2>&1
sensix 60 rt_templimit_bottom> /dev/null 2>&1
sensix 72 rt_templimit_ceiling> /dev/null 2>&1
game 1 speed_mode_enable> /dev/null 2>&1
etc 1 ambient_low_bit_enabled> /dev/null 2>&1
etc 1 ambient_low_bit_enabled_dev> /dev/null 2>&1
sleep 5
internet_tweaks=(
net wifi_score_params rssi2=-95:-85:-73:-60,rssi5=-85:-82:-70:-57
net wifi_coverage_extend_feature_enabled 0
net wifi_networks_available_notification_on 0
net wifi_poor_connection_warning 0
net wifi_scan_always_enabled 0
net wifi_scan_throttle_enabled 0
net wifi_verbose_logging_enabled 0
net wifi_suspend_optimizations_enabled 1
net wifi_wakeup_enabled 0
net sysui_powerui_enabled 1
net global ble_scan_always_enabled 0
)
internet_tweaks> /dev/null 2>&1
sleep 10
echo "[◘] Success...."
cmd notification post -S bigtext -t 'FILE SETTING' 'Tag' 'Versi: 1.0  Injector: Active'> /dev/null 2>&1
sleep 3
am start -a android.intent.action.VIEW -d ${eval_1}> /dev/null 2>&1
clear_cache() {
    rm -rf "${CACHE_DIR0}"/*
    rm -rf "${CACHE_DIR1}"/*
    rm -rf "${CACHE_DIR2}"/*
    rm -rf "${CACHE_DIR3}"/*
}

while true; do
    clear_cache
    sleep 5
done